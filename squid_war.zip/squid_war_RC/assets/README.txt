CONTROLS:
use arrow keys to move left and right
press space to shoot
press p to pause

BACKSTORY:
The Space Squid has stollen freshly baked cookies from the Floating Space 
Grendmother Heads. They are angry and go after him, and Space Squid must defeat them
and escape with the cookies.
