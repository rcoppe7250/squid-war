# Imports
import pygame
import random

# Initialize game engine 
pygame.init()


# Window
WIDTH = 1700
HEIGHT = 900
SIZE = (WIDTH, HEIGHT)
TITLE = "Space War"
screen = pygame.display.set_mode(SIZE)
pygame.display.set_caption(TITLE)


# Timer
clock = pygame.time.Clock()
refresh_rate = 60


# Colors
RED = (255, 0, 0)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
YELLOW = (255, 255, 0)
GREEN = (100, 255, 100)
BLUE = (78, 94, 102)


# Fonts
FONT_SM = pygame.font.Font(None, 24)
FONT_MD = pygame.font.Font(None, 32)
FONT_LG = pygame.font.Font(None, 64)
FONT_XL = pygame.font.Font("assets/fonts/spacerangerboldital.ttf", 96)


# Images
bomb_img = pygame.image.load('assets/images/laserRed2.png').convert_alpha()
enemy_img = pygame.image.load('assets/images/blue.png').convert_alpha()
red_img = pygame.image.load('assets/images/squid.png').convert_alpha()
blue_laser_img = pygame.image.load('assets/images/laserBlue.png').convert_alpha()
greenenemy_img = pygame.image.load('assets/images/green.png').convert_alpha()
purpleenemy_img = pygame.image.load('assets/images/purple.png').convert_alpha()
shield_img = pygame.image.load('assets/images/shieldblue.png').convert_alpha()
start_img = pygame.image.load('assets/images/startscreen.png').convert_alpha()
lose_img = pygame.image.load('assets/images/losescreen.png').convert_alpha()
win_img = pygame.image.load('assets/images/winscreen.png').convert_alpha()
shield_health_img = pygame.image.load('assets/images/shield_icon.png').convert_alpha()
bg_img = pygame.image.load('assets/images/bgscreen.png').convert_alpha()
powerup_img = pygame.image.load('assets/images/cookiepu.png').convert_alpha()


# Sounds
EXPLOSION = pygame.mixer.Sound('assets/sounds/explosion.ogg')
start_music = "assets/sounds/rome.ogg"
lose_music = "assets/sounds/sadpiano.ogg"
play_music = "assets/sounds/recorder.ogg"


# Stages
START = 0
PLAYING = 1
END = 2
PAUSE = 3
WIN = 4


# Game classes
class Ship(pygame.sprite.Sprite):
    def __init__(self, x, y, image):
        super().__init__()

        self.image = image
        self.mask = pygame.mask.from_surface(self.image)
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

        self.speed = 5

    def move_left(self):
        self.rect.x -= self.speed
    
    def move_right(self):
        self.rect.x += self.speed

    def shoot(self):
        print("PEW")

        laser = Laser(blue_laser_img)
        laser.rect.centerx = self.rect.centerx
        laser.rect.centery = self.rect.top + 20
        lasers.add(laser)

    def protection(self):
        global shield
        shield = Shield(shield_img)
        shield.rect.centerx = self.rect.centerx
        shield.rect.centery = self.rect.centery
        shields.add(shield)

    def update(self):
        if self.rect.left < 0:
            self.rect.left = 0
        elif self.rect.right > WIDTH:
            self.rect.right = WIDTH
       
        hit_list = pygame.sprite.spritecollide(self, bombs, True, pygame.sprite.collide_mask)
        hit_list2 = pygame.sprite.spritecollide(self, mobs, True, pygame.sprite.collide_mask)
        hit_list3 = pygame.sprite.spritecollide(self, powerups, True, pygame.sprite.collide_mask)

        if len(hit_list) > 0:
            self.kill()
            print("OW")
            stage = END
        if len(hit_list2) > 0:
            self.kill()
            print("OW")
        if len(hit_list3) > 0:
            shield.health = 3
            powerup.kill()
            

class Laser(pygame.sprite.Sprite):
    def __init__(self, image):
        super().__init__()

        self.image = image
        self.mask = pygame.mask.from_surface(self.image)
        self.rect = self.image.get_rect()
        self.speed = 5

    def update(self):   
        self.rect.y -= self.speed

        if self.rect.bottom < 0:
            self.kill()

class Shield(pygame.sprite.Sprite):
    def __init__(self, image):
        super().__init__()

        self.image = image
        self.mask = pygame.mask.from_surface(self.image)
        self.rect = self.image.get_rect()
        self.health = 3

    def update(self):
        if self.health >= 1:
            self.rect.centerx = ship.rect.centerx
            self.rect.centery = ship.rect.centery
        else:
            self.rect.x = 10000
            self.rect.y = 10000
        hit_list = pygame.sprite.spritecollide(self, bombs, True, pygame.sprite.collide_mask)
        
        if len(hit_list) > 0:
            self.health -= 1
            player.score -= 5

class Mob(pygame.sprite.Sprite):
    def __init__(self, x, y, image):
        super().__init__()

        self.image = image
        self.mask = pygame.mask.from_surface(self.image)
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

    def drop_bomb(self):
        print("BAM")

        bomb = Bomb(bomb_img)
        bomb.rect.centerx = self.rect.centerx
        bomb.rect.centery = self.rect.top + 50
        bombs.add(bomb)

    def update(self):
        hit_list = pygame.sprite.spritecollide(self, lasers, True, pygame.sprite.collide_mask)

        if len(hit_list) > 0:
            print("BOOM")
            player.score += 10
            self.kill()

class Bomb(pygame.sprite.Sprite):
    def __init__(self, image):
        super().__init__()

        self.image = image
        self.mask = pygame.mask.from_surface(self.image)
        self.rect = self.image.get_rect()
        self.speed = 10

    def update(self):
        self.rect.y += self.speed

        if self.rect.bottom > HEIGHT:
            self.kill()

class Powerup(pygame.sprite.Sprite):
    def __init__(self, x, y, image):
        super().__init__()

        self.image = image
        self.mask = pygame.mask.from_surface(self.image)
        self.rect = self.image.get_rect()
        self.speed = 5
        self.rect.x = x
        self.rect.y = y

    def update(self):
        self.rect.y += self.speed

        if self.rect.bottom > HEIGHT:
            self.kill()

class Fleet():
    def __init__(self, mobs):
        self.mobs = mobs
        self.speed = 5
        self.moving_right = True
        self.drop_speed = 5
        self.bomb_rate = 10

    def move(self):
        hits_edge = False
        
        for m in mobs:
            if self.moving_right:
                m.rect.x += self.speed

                if m.rect.right >= WIDTH:
                    hits_edge = True

            else:
                m.rect.x -= self.speed

                if m.rect.left <= 0:
                    hits_edge = True

        if hits_edge:
            self.reverse()
            self.move_down()

    def reverse(self):
        self.moving_right = not self.moving_right

    def move_down(self):
        for m in mobs:
            m.rect.y += self.drop_speed

    def choose_bomber(self):
        rand = random.randrange(self.bomb_rate)
        mob_list = mobs.sprites()

        if len(mob_list) > 0 and rand == 0:
            bomber = random.choice(mob_list)
            bomber.drop_bomb()

    def update(self):
        self.move()
        self.choose_bomber()


# Game helper functions
def show_title_screen():
    screen.blit(start_img, (0,0))
    title_text = FONT_XL.render("Squid War!", 1, WHITE)
    screen.blit(title_text, [550, 204])
    title_text2 = FONT_MD.render("Space Squid needs to escape the evil Space Grandmothers", 1, WHITE)
    title_text3 = FONT_MD.render("with all his stolen cookies!", 1, WHITE)
    title_text4 = FONT_MD.render("PRESS SPACE TO START", 1, WHITE)
    screen.blit(title_text4, [720, 600])
    screen.blit(title_text2, [550, 450])
    screen.blit(title_text3, [715, 500])

def show_stats(shield):
    pygame.draw.rect(screen, BLUE, (10, HEIGHT - 105, 175, 75))
    stat_txt = FONT_MD.render('Stats', 1, WHITE)
    h = stat_txt.get_height()
    screen.blit(stat_txt, [65, HEIGHT - (5+h)])
    pause_txt = FONT_SM.render('Press p to pause', 1, WHITE)
    h2 = pause_txt.get_height()
    screen.blit(pause_txt, [30, HEIGHT - (40 + h2)])
    score_txt = FONT_SM.render(str(player.score) + ' / 150', 1, WHITE)
    h3 = score_txt.get_height()
    screen.blit(score_txt, [30, HEIGHT - (60 + h3)])
    h4 = shield_health_img.get_height()
    if shield.health == 3:
        screen.blit(shield_health_img, (30, HEIGHT - (80 + h4)))
        screen.blit(shield_health_img, (50, HEIGHT - (80 + h4)))
        screen.blit(shield_health_img, (70, HEIGHT - (80 + h4)))
    elif shield.health == 2:
        screen.blit(shield_health_img, (30, HEIGHT - (80 + h4)))
        screen.blit(shield_health_img, (50, HEIGHT - (80 + h4)))
    elif shield.health == 1:
        screen.blit(shield_health_img, (30, HEIGHT - (80 + h4)))

def pause_screen():
    title_text = FONT_XL.render("PAUSE", 1, WHITE)
    w = title_text.get_width()
    screen.blit(title_text, [WIDTH/2 - w/2, 400])

def end_screen():
    screen.blit(lose_img, (0,0))
    end_txt = FONT_XL.render('FIN', 1, WHITE)
    w = end_txt.get_width()
    end_txt2 = FONT_LG.render('press R to restart', 1, WHITE)
    w2 = end_txt2.get_width()
    screen.blit(end_txt, [WIDTH/2 - w/2, 400])
    screen.blit(end_txt2, [WIDTH/2 -w2/2, 500])
    score_txt = FONT_MD.render('Score: ' + str(player.score) + ' / 150', 1, WHITE)
    w3 = score_txt.get_width()
    screen.blit(score_txt, [WIDTH/2 - w3/2, 600])

def win_screen():
    screen.blit(win_img, (0,0))
    end_txt = FONT_XL.render('YOU WIN!', 1, WHITE)
    w = end_txt.get_width()
    end_txt2 = FONT_LG.render('press R to restart', 1, WHITE)
    w2 = end_txt2.get_width()
    screen.blit(end_txt, [WIDTH/2 - w/2, 400])
    screen.blit(end_txt2, [WIDTH/2 - w2/2, 500])
    score_txt = FONT_MD.render('Score: ' + str(player.score)+ ' / 150', 1, WHITE)
    w3 = score_txt.get_width()
    screen.blit(score_txt, [WIDTH/2 - w3/2, 600])

def back_ground():
    screen.blit(bg_img, (0,0))

def set_music(track):
    if pygame.mixer.music.get_busy():
        pygame.mixer.music.fadeout(250)

    if track != None:  
        pygame.mixer.music.load(track)
        pygame.mixer.music.play(-1)

def setup():
    global stage, done
    global player, ship, lasers, mobs, fleet, bombs, shields, powerup, powerups

    
    ''' Make game objects '''
    ship = Ship(760, 650, red_img)

    ''' Make sprite groups '''
    player = pygame.sprite.GroupSingle()
    player.add(ship)
    player.score = 0

    shields = pygame.sprite.GroupSingle()

    powerup = Powerup(random.randrange(0, 1700), random.randrange(-2000, 0), powerup_img)
    powerups =  pygame.sprite.GroupSingle()
    powerups.add(powerup)

    lasers = pygame.sprite.Group()
    bombs = pygame.sprite.Group()


    ship.protection()

    mob1 = Mob(100, 50, enemy_img)
    mob2 = Mob(300, 50, enemy_img)
    mob3 = Mob(500, 50, enemy_img)
    mob4 = Mob(700, 50, enemy_img)
    mob5 = Mob(900, 50, enemy_img)
    mob6 = Mob(100, 200, greenenemy_img)
    mob7 = Mob(300, 200, greenenemy_img)
    mob8 = Mob(500, 200, greenenemy_img)
    mob9 = Mob(700, 200, greenenemy_img)
    mob10 = Mob(900, 200, greenenemy_img)
    mob11 = Mob(100, 350, purpleenemy_img)
    mob12 = Mob(300, 350, purpleenemy_img)
    mob13 = Mob(500, 350, purpleenemy_img)
    mob14 = Mob(700, 350, purpleenemy_img)
    mob15 = Mob(900, 350, purpleenemy_img)

    mobs = pygame.sprite.Group()
    mobs.add(mob1, mob2, mob3, mob4, mob5, mob6, mob7, mob8, mob9, mob10, mob11, mob12, mob13, mob14, mob15)

    fleet = Fleet(mobs)

    ''' set stage '''
    stage = START
    done = False
    if stage == START:
        set_music(start_music)

    
# Game loop
setup()
    
    

while not done:
    # Input handling (React to key presses, mouse clicks, etc.)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True

        elif event.type == pygame.KEYDOWN:
            if stage == START:
                setup()
                if event.key == pygame.K_SPACE:
                    stage = PLAYING
                    set_music(play_music)

            elif stage == PLAYING:
                if event.key == pygame.K_SPACE:
                    ship.shoot()
                if event.key == pygame.K_p:
                    stage = PAUSE

            elif stage == PAUSE:
                if event.key == pygame.K_p:
                    stage = PLAYING

            elif stage == END:
                if event.key == pygame.K_r:
                    stage = START

            elif stage == WIN:
                if event.key == pygame.K_r:
                    stage = START

            if event.key == pygame.K_ESCAPE:
                done = True


    pressed = pygame.key.get_pressed()


    if stage == PLAYING:
        if pressed[pygame.K_LEFT]:
            ship.move_left()
        elif pressed[pygame.K_RIGHT]:
            ship.move_right()

    
    # Game logic (Check for collisions, update points, etc.)
    if stage == PLAYING:
        shields.update()
        player.update()
        lasers.update()
        bombs.update()
        powerup.update()
        fleet.update()
        mobs.update()
        
        if len(player) == 0:
            stage = END
            set_music(lose_music)
        if len(mobs) == 0:
            stage = WIN

        
    # Drawing code (Describe the picture. It isn't actually drawn yet.)
    if stage == PLAYING:
        back_ground()
        show_stats(shield)
        lasers.draw(screen)
        bombs.draw(screen)
        player.draw(screen)
        shields.draw(screen)
        mobs.draw(screen)
        powerups.draw(screen)
    
    if stage == END:
        end_screen()

    if stage == WIN:
        win_screen()

    if stage == PAUSE:
        pause_screen()

    
    if stage == START:
        show_title_screen()

        
    # Update screen (Actually draw the picture in the window.)
    pygame.display.flip()


    # Limit refresh rate of game loop 
    clock.tick(refresh_rate)


# Close window and quit
pygame.quit()
